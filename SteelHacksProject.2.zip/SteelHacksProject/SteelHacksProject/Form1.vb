﻿Imports System.IO
Imports System.IO.Ports
Imports System.Threading

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MainMenu.Show()
        Me.WindowState = FormWindowState.Minimized

        SerialPort1.Open()
        SerialPort1.Write("c")
        SerialPort1.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles clrBtn.Click
        If (RichTextBox1.Text IsNot "") Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if 'Clear' button clicked " & vbCrLf &
                vbTab & "then all lights turned off"
        ElseIf (RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if 'Clear' button clicked " & vbCrLf & vbTab & "then all lights turned off"
        End If

        cBoxRed.Checked = False
        cBoxBlue.Checked = False
        cBoxOrange.Checked = False
        cBoxWhite.Checked = False
        cBoxGreen.Checked = False

        SerialPort1.Open()
        SerialPort1.Write("c")
        SerialPort1.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles lightAllBtn.Click
        If (RichTextBox1.Text IsNot "") Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if 'Light Everything!' button clicked " & vbCrLf & vbTab & "then all lights turned on"
        ElseIf (RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if 'Light Everything!' button clicked " & vbCrLf & vbTab & "then all lights turned on"
        End If

        cBoxRed.Checked = True
        cBoxWhite.Checked = True
        cBoxOrange.Checked = True
        cBoxGreen.Checked = True
        cBoxBlue.Checked = True

        SerialPort1.Open()
        SerialPort1.Write("f")
        SerialPort1.Close()
    End Sub

    Private Sub cBoxRed_Click(sender As Object, e As EventArgs) Handles cBoxRed.Click
        If cBoxRed.Checked = True And RichTextBox1.Text IsNot "" Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if RED is checked" & vbCrLf & vbTab & "then RED lights up"
        ElseIf (cBoxRed.Checked = True And RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if RED is checked" & vbCrLf & vbTab & "then RED lights up"
        ElseIf (cBoxRed.Checked = False) Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if RED is unchecked" & vbCrLf & vbTab & "then RED turns off"
        End If
        SerialPort1.Open()
        SerialPort1.Write("r")
        SerialPort1.Close()
    End Sub

    Private Sub cBoxWhite_Click(sender As Object, e As EventArgs) Handles cBoxWhite.Click
        If cBoxWhite.Checked = True And RichTextBox1.Text IsNot "" Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if WHITE is checked" & vbCrLf & vbTab & "then WHITE lights up"
        ElseIf (cBoxWhite.Checked = True And RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if WHITE is checked" & vbCrLf & vbTab & "then WHITE lights up"
        ElseIf (cBoxWhite.Checked = False) Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if WHITE is unchecked" & vbCrLf & vbTab & "then WHITE turns off"
        End If
        SerialPort1.Open()
        SerialPort1.Write("w")
        SerialPort1.Close()
    End Sub

    Private Sub cBoxOrange_Click(sender As Object, e As EventArgs) Handles cBoxOrange.Click
        If cBoxOrange.Checked = True And RichTextBox1.Text IsNot "" Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if ORANGE is checked" & vbCrLf & vbTab & "then ORANGE lights up"
        ElseIf (cBoxOrange.Checked = True And RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if ORANGE is checked" & vbCrLf & vbTab & "then ORANGE lights up"
        ElseIf (cBoxOrange.Checked = False) Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if ORANGE is unchecked" & vbCrLf & vbTab & "then ORANGE turns off"
        End If
        SerialPort1.Open()
        SerialPort1.Write("o")
        SerialPort1.Close()
    End Sub

    Private Sub cBoxBlue_Click(sender As Object, e As EventArgs) Handles cBoxBlue.Click
        If cBoxBlue.Checked = True And RichTextBox1.Text IsNot "" Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if BLUE is checked" & vbCrLf & vbTab & "then BLUE lights up"
        ElseIf (cBoxBlue.Checked = True And RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if BLUE is checked" & vbCrLf & vbTab & "then BLUE lights up"
        ElseIf (cBoxBlue.Checked = False) Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if BLUE is unchecked" & vbCrLf & vbTab & "then BLUE turns off"
        End If
        SerialPort1.Open()
        SerialPort1.Write("b")
        SerialPort1.Close()
    End Sub

    Private Sub cBoxGreen_Click(sender As Object, e As EventArgs) Handles cBoxGreen.Click
        If cBoxGreen.Checked = True And RichTextBox1.Text IsNot "" Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if GREEN is checked" & vbCrLf & vbTab & "then GREEN lights up"
        ElseIf (cBoxGreen.Checked = True And RichTextBox1.Text Is "") Then
            RichTextBox1.Text = "if GREEN is checked" & vbCrLf & vbTab & "then GREEN lights up"
        ElseIf (cBoxRed.Checked = False) Then
            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & "if GREEN is unchecked" & vbCrLf & vbTab & "then GREEN turns off"
        End If
        SerialPort1.Open()
        SerialPort1.Write("g")
        SerialPort1.Close()
    End Sub
End Class
