﻿Public Class WhileLoop


    Private Sub btnClr_Click(sender As Object, e As EventArgs) Handles btnClr.Click
        SerialPort1.Open()
        SerialPort1.Write("c")
        SerialPort1.Close()

        RichTextBox1.Text = ""
    End Sub

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        RichTextBox1.Text = "While the number of blinks <= 10:"
        SerialPort1.Open()

        Dim myarray() As String = {"b", "o", "g", "w", "r"}

        For i = 0 To 4

            SerialPort1.Write(myarray(i))
            System.Threading.Thread.Sleep(1000)

            SerialPort1.Write(myarray(i))
            System.Threading.Thread.Sleep(1000)

            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & vbTab & "numberOfBlinks = " & i

        Next

        For i = 0 To 4

            SerialPort1.Write(myarray(i))
            System.Threading.Thread.Sleep(1000)

            SerialPort1.Write(myarray(i))
            System.Threading.Thread.Sleep(1000)

            RichTextBox1.Text = RichTextBox1.Text & vbCrLf & vbTab & "numberOfBlinks = " & (i + 5)
        Next

        SerialPort1.Close()
    End Sub
End Class