﻿Public Class MainMenu

    Private Sub rBtnFor_Click(sender As Object, e As EventArgs) Handles rBtnFor.Click
        ForLoop.Show()
    End Sub

    Private Sub rBtnIf_Click(sender As Object, e As EventArgs) Handles rBtnIf.Click
        Form1.Show()
        Form1.WindowState = FormWindowState.Normal
    End Sub

    Private Sub rBtnWhile_CheckedChanged(sender As Object, e As EventArgs) Handles rBtnWhile.CheckedChanged
        WhileLoop.Show()
    End Sub
End Class