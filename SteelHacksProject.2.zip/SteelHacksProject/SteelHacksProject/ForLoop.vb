﻿Public Class ForLoop

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim myarray() As String = {"b", "o", "g", "w", "r"}
        Dim value = Val(TextBox1.Text)
        RichTextBox1.Text = "For i = 0 to " & (value - 1) & vbCrLf & "Light Up:"
        If value >= 1 And value <= 5 Then
            For i = 0 To (value - 1)
                SerialPort1.Open()
                SerialPort1.Write(myarray(i))
                System.Threading.Thread.Sleep(1000)
                SerialPort1.Close()
                If i = 0 Then
                    RichTextBox1.Text = RichTextBox1.Text + vbCrLf & vbTab & "BLUE when i = 0"
                ElseIf i = 1 Then
                    RichTextBox1.Text = RichTextBox1.Text + vbCrLf & vbTab & "ORANGE when i = 1"
                ElseIf i = 2 Then
                    RichTextBox1.Text = RichTextBox1.Text + vbCrLf & vbTab & "GREEN when i = 2"
                ElseIf i = 3 Then
                    RichTextBox1.Text = RichTextBox1.Text + vbCrLf & vbTab & "WHITE when i = 3"
                ElseIf i = 4 Then
                    RichTextBox1.Text = RichTextBox1.Text + vbCrLf & vbTab & "RED when i = 4"
                End If
            Next
        Else
            MsgBox("I'm sorry, your input was invalid!")
        End If
    End Sub

    Private Sub btnClr_Click(sender As Object, e As EventArgs) Handles btnClr.Click
        SerialPort1.Open()
        SerialPort1.Write("c")
        SerialPort1.Close()

        TextBox1.Text = ""
        RichTextBox1.Text = ""
    End Sub
End Class