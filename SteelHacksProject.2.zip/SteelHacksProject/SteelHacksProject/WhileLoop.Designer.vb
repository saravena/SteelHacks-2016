﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class WhileLoop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.cBoxRed = New System.Windows.Forms.CheckBox()
        Me.cBoxOrange = New System.Windows.Forms.CheckBox()
        Me.cBoxGreen = New System.Windows.Forms.CheckBox()
        Me.cBoxBlue = New System.Windows.Forms.CheckBox()
        Me.cBoxWhite = New System.Windows.Forms.CheckBox()
        Me.btnClr = New System.Windows.Forms.Button()
        Me.btnGo = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(140, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 1
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 167)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.Size = New System.Drawing.Size(260, 82)
        Me.RichTextBox1.TabIndex = 17
        Me.RichTextBox1.Text = ""
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM3"
        '
        'cBoxRed
        '
        Me.cBoxRed.AutoSize = True
        Me.cBoxRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxRed.ForeColor = System.Drawing.Color.Red
        Me.cBoxRed.Location = New System.Drawing.Point(12, 11)
        Me.cBoxRed.Name = "cBoxRed"
        Me.cBoxRed.Size = New System.Drawing.Size(53, 20)
        Me.cBoxRed.TabIndex = 18
        Me.cBoxRed.Text = "Red"
        Me.cBoxRed.UseVisualStyleBackColor = True
        '
        'cBoxOrange
        '
        Me.cBoxOrange.AutoSize = True
        Me.cBoxOrange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxOrange.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cBoxOrange.Location = New System.Drawing.Point(12, 37)
        Me.cBoxOrange.Name = "cBoxOrange"
        Me.cBoxOrange.Size = New System.Drawing.Size(72, 20)
        Me.cBoxOrange.TabIndex = 19
        Me.cBoxOrange.Text = "Orange"
        Me.cBoxOrange.UseVisualStyleBackColor = True
        '
        'cBoxGreen
        '
        Me.cBoxGreen.AutoSize = True
        Me.cBoxGreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxGreen.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cBoxGreen.Location = New System.Drawing.Point(12, 63)
        Me.cBoxGreen.Name = "cBoxGreen"
        Me.cBoxGreen.Size = New System.Drawing.Size(64, 20)
        Me.cBoxGreen.TabIndex = 20
        Me.cBoxGreen.Text = "Green"
        Me.cBoxGreen.UseVisualStyleBackColor = True
        '
        'cBoxBlue
        '
        Me.cBoxBlue.AutoSize = True
        Me.cBoxBlue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxBlue.ForeColor = System.Drawing.Color.Blue
        Me.cBoxBlue.Location = New System.Drawing.Point(12, 89)
        Me.cBoxBlue.Name = "cBoxBlue"
        Me.cBoxBlue.Size = New System.Drawing.Size(54, 20)
        Me.cBoxBlue.TabIndex = 21
        Me.cBoxBlue.Text = "Blue"
        Me.cBoxBlue.UseVisualStyleBackColor = True
        '
        'cBoxWhite
        '
        Me.cBoxWhite.AutoSize = True
        Me.cBoxWhite.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxWhite.Location = New System.Drawing.Point(12, 115)
        Me.cBoxWhite.Name = "cBoxWhite"
        Me.cBoxWhite.Size = New System.Drawing.Size(61, 20)
        Me.cBoxWhite.TabIndex = 22
        Me.cBoxWhite.Text = "White"
        Me.cBoxWhite.UseVisualStyleBackColor = True
        '
        'btnClr
        '
        Me.btnClr.Location = New System.Drawing.Point(143, 89)
        Me.btnClr.Name = "btnClr"
        Me.btnClr.Size = New System.Drawing.Size(77, 46)
        Me.btnClr.TabIndex = 23
        Me.btnClr.Text = "Clear"
        Me.btnClr.UseVisualStyleBackColor = True
        '
        'btnGo
        '
        Me.btnGo.Location = New System.Drawing.Point(143, 18)
        Me.btnGo.Name = "btnGo"
        Me.btnGo.Size = New System.Drawing.Size(77, 47)
        Me.btnGo.TabIndex = 24
        Me.btnGo.Text = "Go!"
        Me.btnGo.UseVisualStyleBackColor = True
        '
        'WhileLoop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.btnClr)
        Me.Controls.Add(Me.cBoxWhite)
        Me.Controls.Add(Me.cBoxBlue)
        Me.Controls.Add(Me.cBoxGreen)
        Me.Controls.Add(Me.cBoxOrange)
        Me.Controls.Add(Me.cBoxRed)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Name = "WhileLoop"
        Me.Text = "While Loop"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents cBoxRed As CheckBox
    Friend WithEvents cBoxOrange As CheckBox
    Friend WithEvents cBoxGreen As CheckBox
    Friend WithEvents cBoxBlue As CheckBox
    Friend WithEvents cBoxWhite As CheckBox
    Friend WithEvents btnClr As Button
    Friend WithEvents btnGo As Button
End Class
