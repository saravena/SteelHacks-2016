﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.clrBtn = New System.Windows.Forms.Button()
        Me.lightAllBtn = New System.Windows.Forms.Button()
        Me.cBoxRed = New System.Windows.Forms.CheckBox()
        Me.cBoxOrange = New System.Windows.Forms.CheckBox()
        Me.cBoxGreen = New System.Windows.Forms.CheckBox()
        Me.cBoxBlue = New System.Windows.Forms.CheckBox()
        Me.cBoxWhite = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(38, 100)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox1.ShowSelectionMargin = True
        Me.RichTextBox1.Size = New System.Drawing.Size(297, 183)
        Me.RichTextBox1.TabIndex = 3
        Me.RichTextBox1.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(35, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 18)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Generated code: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Colors to Light:"
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM3"
        '
        'clrBtn
        '
        Me.clrBtn.Location = New System.Drawing.Point(298, 58)
        Me.clrBtn.Name = "clrBtn"
        Me.clrBtn.Size = New System.Drawing.Size(75, 23)
        Me.clrBtn.TabIndex = 11
        Me.clrBtn.Text = "Clear"
        Me.clrBtn.UseVisualStyleBackColor = True
        '
        'lightAllBtn
        '
        Me.lightAllBtn.Location = New System.Drawing.Point(204, 58)
        Me.lightAllBtn.Name = "lightAllBtn"
        Me.lightAllBtn.Size = New System.Drawing.Size(75, 23)
        Me.lightAllBtn.TabIndex = 12
        Me.lightAllBtn.Text = "Light Up Everything!"
        Me.lightAllBtn.UseVisualStyleBackColor = True
        '
        'cBoxRed
        '
        Me.cBoxRed.AutoSize = True
        Me.cBoxRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxRed.ForeColor = System.Drawing.Color.Red
        Me.cBoxRed.Location = New System.Drawing.Point(120, 9)
        Me.cBoxRed.Name = "cBoxRed"
        Me.cBoxRed.Size = New System.Drawing.Size(49, 17)
        Me.cBoxRed.TabIndex = 13
        Me.cBoxRed.Text = "Red"
        Me.cBoxRed.UseVisualStyleBackColor = True
        '
        'cBoxOrange
        '
        Me.cBoxOrange.AutoSize = True
        Me.cBoxOrange.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxOrange.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cBoxOrange.Location = New System.Drawing.Point(120, 32)
        Me.cBoxOrange.Name = "cBoxOrange"
        Me.cBoxOrange.Size = New System.Drawing.Size(67, 17)
        Me.cBoxOrange.TabIndex = 14
        Me.cBoxOrange.Text = "Orange"
        Me.cBoxOrange.UseVisualStyleBackColor = True
        '
        'cBoxGreen
        '
        Me.cBoxGreen.AutoSize = True
        Me.cBoxGreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxGreen.ForeColor = System.Drawing.Color.LimeGreen
        Me.cBoxGreen.Location = New System.Drawing.Point(194, 8)
        Me.cBoxGreen.Name = "cBoxGreen"
        Me.cBoxGreen.Size = New System.Drawing.Size(60, 17)
        Me.cBoxGreen.TabIndex = 15
        Me.cBoxGreen.Text = "Green"
        Me.cBoxGreen.UseVisualStyleBackColor = True
        '
        'cBoxBlue
        '
        Me.cBoxBlue.AutoSize = True
        Me.cBoxBlue.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxBlue.ForeColor = System.Drawing.Color.Blue
        Me.cBoxBlue.Location = New System.Drawing.Point(194, 32)
        Me.cBoxBlue.Name = "cBoxBlue"
        Me.cBoxBlue.Size = New System.Drawing.Size(51, 17)
        Me.cBoxBlue.TabIndex = 16
        Me.cBoxBlue.Text = "Blue"
        Me.cBoxBlue.UseVisualStyleBackColor = True
        '
        'cBoxWhite
        '
        Me.cBoxWhite.AutoSize = True
        Me.cBoxWhite.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cBoxWhite.ForeColor = System.Drawing.Color.Black
        Me.cBoxWhite.Location = New System.Drawing.Point(276, 8)
        Me.cBoxWhite.Name = "cBoxWhite"
        Me.cBoxWhite.Size = New System.Drawing.Size(59, 17)
        Me.cBoxWhite.TabIndex = 17
        Me.cBoxWhite.Text = "White"
        Me.cBoxWhite.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(395, 316)
        Me.Controls.Add(Me.cBoxWhite)
        Me.Controls.Add(Me.cBoxBlue)
        Me.Controls.Add(Me.cBoxGreen)
        Me.Controls.Add(Me.cBoxOrange)
        Me.Controls.Add(Me.cBoxRed)
        Me.Controls.Add(Me.lightAllBtn)
        Me.Controls.Add(Me.clrBtn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "If Statement"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents SerialPort1 As IO.Ports.SerialPort
    Friend WithEvents clrBtn As Button
    Friend WithEvents lightAllBtn As Button
    Friend WithEvents cBoxRed As CheckBox
    Friend WithEvents cBoxOrange As CheckBox
    Friend WithEvents cBoxGreen As CheckBox
    Friend WithEvents cBoxBlue As CheckBox
    Friend WithEvents cBoxWhite As CheckBox
End Class
