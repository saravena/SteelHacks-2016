﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rBtnIf = New System.Windows.Forms.RadioButton()
        Me.rBtnFor = New System.Windows.Forms.RadioButton()
        Me.rBtnWhile = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'rBtnIf
        '
        Me.rBtnIf.AutoSize = True
        Me.rBtnIf.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rBtnIf.Location = New System.Drawing.Point(65, 65)
        Me.rBtnIf.Name = "rBtnIf"
        Me.rBtnIf.Size = New System.Drawing.Size(116, 24)
        Me.rBtnIf.TabIndex = 0
        Me.rBtnIf.TabStop = True
        Me.rBtnIf.Text = "If Statement"
        Me.rBtnIf.UseVisualStyleBackColor = True
        '
        'rBtnFor
        '
        Me.rBtnFor.AutoSize = True
        Me.rBtnFor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rBtnFor.Location = New System.Drawing.Point(65, 108)
        Me.rBtnFor.Name = "rBtnFor"
        Me.rBtnFor.Size = New System.Drawing.Size(91, 24)
        Me.rBtnFor.TabIndex = 1
        Me.rBtnFor.TabStop = True
        Me.rBtnFor.Text = "For Loop"
        Me.rBtnFor.UseVisualStyleBackColor = True
        '
        'rBtnWhile
        '
        Me.rBtnWhile.AutoSize = True
        Me.rBtnWhile.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rBtnWhile.Location = New System.Drawing.Point(65, 154)
        Me.rBtnWhile.Name = "rBtnWhile"
        Me.rBtnWhile.Size = New System.Drawing.Size(106, 24)
        Me.rBtnWhile.TabIndex = 2
        Me.rBtnWhile.TabStop = True
        Me.rBtnWhile.Text = "While Loop"
        Me.rBtnWhile.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(271, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Control Structures Available for Demo:"
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.rBtnWhile)
        Me.Controls.Add(Me.rBtnFor)
        Me.Controls.Add(Me.rBtnIf)
        Me.Name = "MainMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MainMenu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rBtnIf As RadioButton
    Friend WithEvents rBtnFor As RadioButton
    Friend WithEvents rBtnWhile As RadioButton
    Friend WithEvents Label1 As Label
End Class
